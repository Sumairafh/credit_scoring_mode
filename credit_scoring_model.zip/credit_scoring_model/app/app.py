"""
app.py  —  Credit Scoring Model · Streamlit Web Application
────────────────────────────────────────────────────────────
Run with:
    streamlit run app/app.py
"""

import os
import sys
import numpy as np
import streamlit as st

# Allow the app to import from src/
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from predict import predict_single, load_artifacts

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Credit Scoring Model",
    page_icon="💳",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:wght@300;400;500;600&display=swap');

html, body, [class*="css"] {
    font-family: 'DM Sans', sans-serif;
}

h1, h2, h3 { font-family: 'DM Serif Display', serif; }

.main-header {
    text-align: center;
    padding: 2rem 0 1rem;
    border-bottom: 3px solid #1E3A5F;
    margin-bottom: 2rem;
}

.metric-card {
    background: linear-gradient(135deg, #1E3A5F 0%, #2563EB 100%);
    border-radius: 16px;
    padding: 1.5rem;
    color: white;
    text-align: center;
    box-shadow: 0 8px 32px rgba(37,99,235,0.25);
}

.result-good {
    background: linear-gradient(135deg, #064E3B, #065F46);
    border-left: 6px solid #10B981;
    border-radius: 12px;
    padding: 1.5rem 2rem;
    color: white;
    margin: 1rem 0;
}

.result-bad {
    background: linear-gradient(135deg, #7F1D1D, #991B1B);
    border-left: 6px solid #EF4444;
    border-radius: 12px;
    padding: 1.5rem 2rem;
    color: white;
    margin: 1rem 0;
}

.risk-badge-low    { background:#10B981; color:white; border-radius:8px; padding:6px 16px; font-weight:600; }
.risk-badge-medium { background:#F59E0B; color:white; border-radius:8px; padding:6px 16px; font-weight:600; }
.risk-badge-high   { background:#EF4444; color:white; border-radius:8px; padding:6px 16px; font-weight:600; }

.stSlider > div[data-baseweb="slider"] > div { background:#2563EB; }

footer { visibility: hidden; }
</style>
""", unsafe_allow_html=True)


# ── Header ────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="main-header">
    <h1>💳 Credit Scoring Model</h1>
    <p style="color:#64748B; font-size:1.1rem;">
        AI-powered creditworthiness assessment using Machine Learning
    </p>
</div>
""", unsafe_allow_html=True)


# ── Sidebar: model info ───────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ℹ️ About")
    st.info(
        "This tool uses a trained **Random Forest / Logistic Regression** "
        "model to predict whether an applicant is a **Good** or **Bad** "
        "credit risk based on their financial profile."
    )

    st.markdown("## 🎯 Risk Levels")
    st.markdown("""
| Level | Probability |
|-------|------------|
| 🟢 Low    | ≥ 60 % |
| 🟡 Medium | 35 – 60 % |
| 🔴 High   | < 35 % |
""")

    st.markdown("## 📊 Model Info")
    try:
        _, _, meta = load_artifacts()
        st.success(f"**Model:** {meta.get('best_model_name','–')}")
        m = meta.get("metrics", {})
        if m:
            st.metric("Accuracy",  f"{m.get('accuracy',0):.2%}")
            st.metric("ROC-AUC",   f"{m.get('roc_auc',0):.4f}")
            st.metric("F1 Score",  f"{m.get('f1',0):.4f}")
    except Exception:
        st.warning("Model not loaded yet. Run `python src/train_model.py` first.")


# ── Input form ────────────────────────────────────────────────────────────────
st.markdown("## 📋 Applicant Information")
st.markdown("Fill in the applicant's financial details below, then click **Predict**.")

col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("### 👤 Personal")
    age = st.number_input("Age", min_value=18, max_value=100, value=35,
                          help="Applicant's age in years")
    income = st.number_input("Annual Income ($)", min_value=0, max_value=1_000_000,
                             value=65_000, step=1000,
                             help="Total yearly income before tax")
    employment_years = st.number_input("Employment Years", min_value=0, max_value=50,
                                       value=8,
                                       help="Years continuously employed")

with col2:
    st.markdown("### 💰 Financial")
    debt = st.number_input("Current Debt ($)", min_value=0, max_value=500_000,
                           value=12_000, step=500,
                           help="Total outstanding debt (credit cards, loans, etc.)")
    loan_amount = st.number_input("Requested Loan ($)", min_value=0, max_value=500_000,
                                  value=15_000, step=500,
                                  help="Amount of the loan being applied for")
    credit_utilization = st.slider("Credit Utilization", 0.0, 1.0, 0.30, 0.01,
                                   format="%.0f%%",
                                   help="Current credit used vs. total available (0 – 100 %)")

with col3:
    st.markdown("### 📈 Credit History")
    credit_history_years = st.number_input("Credit History (years)", min_value=0,
                                           max_value=50, value=10)
    number_of_credit_cards = st.number_input("Number of Credit Cards", min_value=0,
                                             max_value=30, value=3)
    payment_history_score = st.slider("Payment History Score", 300, 850, 720,
                                      help="Credit bureau score (300 = poor, 850 = excellent)")
    missed_payments = st.number_input("Missed Payments (total)", min_value=0,
                                      max_value=50, value=1)


# ── Predict button ────────────────────────────────────────────────────────────
st.markdown("---")
predict_col, _ = st.columns([1, 3])
with predict_col:
    predict_clicked = st.button("🔍 Predict Creditworthiness", use_container_width=True,
                                type="primary")

if predict_clicked:
    input_data = {
        "age":                   age,
        "income":                income,
        "employment_years":      employment_years,
        "debt":                  debt,
        "loan_amount":           loan_amount,
        "credit_history_years":  credit_history_years,
        "number_of_credit_cards": number_of_credit_cards,
        "payment_history_score": payment_history_score,
        "missed_payments":       missed_payments,
        "credit_utilization":    credit_utilization,
    }

    with st.spinner("Analysing applicant profile …"):
        try:
            result = predict_single(input_data)
        except FileNotFoundError as e:
            st.error(str(e))
            st.stop()

    prediction  = result["prediction"]
    probability = result["probability"]
    risk_level  = result["risk_level"]

    # ── Result banner ─────────────────────────────────────────────────────────
    st.markdown("## 🎯 Prediction Result")

    if prediction == 1:
        st.markdown(f"""
<div class="result-good">
    <h2 style="margin:0">✅ Good Credit Risk</h2>
    <p style="margin:4px 0 0; opacity:0.85">
        This applicant is likely to repay the loan.
    </p>
</div>
""", unsafe_allow_html=True)
    else:
        st.markdown(f"""
<div class="result-bad">
    <h2 style="margin:0">❌ Bad Credit Risk</h2>
    <p style="margin:4px 0 0; opacity:0.85">
        This applicant presents a high default risk.
    </p>
</div>
""", unsafe_allow_html=True)

    # ── Metrics row ───────────────────────────────────────────────────────────
    m1, m2, m3 = st.columns(3)

    with m1:
        st.metric(
            label="Probability (Good Credit)",
            value=f"{probability:.1%}",
        )

    with m2:
        # Parse risk level text
        if "LOW"    in risk_level: badge = "risk-badge-low";    level_text = "🟢 Low Risk"
        elif "MED"  in risk_level: badge = "risk-badge-medium"; level_text = "🟡 Medium Risk"
        else:                      badge = "risk-badge-high";   level_text = "🔴 High Risk"
        st.metric(label="Risk Level", value=level_text)

    with m3:
        st.metric(label="Decision", value="Approve ✅" if prediction == 1 else "Decline ❌")

    # ── Probability gauge ─────────────────────────────────────────────────────
    st.markdown("### Probability Gauge")

    bar_color = "#10B981" if probability >= 0.60 else ("#F59E0B" if probability >= 0.35 else "#EF4444")
    st.markdown(f"""
<div style="background:#E2E8F0;border-radius:12px;height:28px;overflow:hidden;margin:8px 0 4px;">
    <div style="width:{probability*100:.1f}%;background:{bar_color};height:100%;
                border-radius:12px;transition:width .5s ease;display:flex;
                align-items:center;justify-content:flex-end;padding-right:10px;">
        <span style="color:white;font-weight:600;font-size:.85rem;">{probability:.1%}</span>
    </div>
</div>
<p style="color:#64748B;font-size:.85rem;margin:0;">
    0 % (Very High Risk) ──────────────────── 100 % (Very Low Risk)
</p>
""", unsafe_allow_html=True)

    # ── Input summary ─────────────────────────────────────────────────────────
    with st.expander("📄 View Input Summary"):
        import pandas as pd
        summary_df = pd.DataFrame([input_data]).T
        summary_df.columns = ["Value"]
        summary_df.index.name = "Feature"
        st.dataframe(summary_df, use_container_width=True)

    # ── Derived ratios ────────────────────────────────────────────────────────
    with st.expander("🔬 Derived Financial Ratios"):
        dti = debt / max(income, 1)
        lti = loan_amount / max(income, 1)
        st.markdown(f"""
| Ratio | Value | Interpretation |
|-------|-------|---------------|
| Debt-to-Income | {dti:.2f} | {'✅ Healthy (< 0.4)' if dti < 0.4 else '⚠️ High (≥ 0.4)'} |
| Loan-to-Income | {lti:.2f} | {'✅ Manageable (< 0.3)' if lti < 0.3 else '⚠️ High (≥ 0.3)'} |
| Credit Utilization | {credit_utilization:.0%} | {'✅ Good (< 50 %)' if credit_utilization < 0.5 else '⚠️ High (≥ 50 %)'} |
| Missed Payments | {missed_payments} | {'✅ Clean' if missed_payments == 0 else ('⚠️ Some' if missed_payments < 3 else '❌ Concerning')} |
""")

# ── Footer ────────────────────────────────────────────────────────────────────
st.markdown("---")
st.markdown(
    "<p style='text-align:center;color:#94A3B8;font-size:.85rem;'>"
    "Credit Scoring Model · Built with Python, scikit-learn & Streamlit"
    "</p>",
    unsafe_allow_html=True,
)
