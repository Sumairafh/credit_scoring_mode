"""
predict.py
──────────
Load the saved model and scaler, then make predictions on new data.

Usage (command line):
    python src/predict.py

Usage (import):
    from predict import predict_single, load_artifacts
"""

import os
import sys
import numpy as np
import joblib
import pandas as pd

sys.path.insert(0, os.path.dirname(__file__))
from feature_engineering import engineer_features, ALL_FEATURES
from utils import get_logger, model_path, data_path

log = get_logger("predict")

# ── Label map ────────────────────────────────────────────────────────────────
LABEL_MAP = {0: "Bad Credit Risk ❌", 1: "Good Credit Risk ✅"}
RISK_LEVELS = {
    (0.00, 0.35): "HIGH RISK 🔴",
    (0.35, 0.60): "MEDIUM RISK 🟡",
    (0.60, 1.01): "LOW RISK 🟢",
}


def load_artifacts():
    """Load the trained model, scaler, and metadata from disk."""
    m_path = model_path()
    s_path = os.path.join(data_path("processed"), "scaler.pkl")
    meta_path = model_path("model_meta.pkl")

    if not os.path.exists(m_path):
        raise FileNotFoundError(
            f"Model not found at {m_path}.\n"
            "Run  python src/train_model.py  first."
        )

    model  = joblib.load(m_path)
    scaler = joblib.load(s_path)
    meta   = joblib.load(meta_path) if os.path.exists(meta_path) else {}
    log.info(f"Loaded model: {meta.get('best_model_name', 'unknown')}")
    return model, scaler, meta


def get_risk_level(probability: float) -> str:
    """Map a probability score to a human-readable risk level."""
    for (lo, hi), label in RISK_LEVELS.items():
        if lo <= probability < hi:
            return label
    return "UNKNOWN"


def predict_single(input_dict: dict) -> dict:
    """
    Make a prediction for a single applicant.

    Parameters
    ----------
    input_dict : dict
        Keys must match the 10 original feature names.

    Returns
    -------
    dict with keys: prediction, label, probability, risk_level
    """
    model, scaler, meta = load_artifacts()

    # Build a one-row DataFrame from the input
    df = pd.DataFrame([input_dict])

    # Apply the same feature engineering used during training
    df = engineer_features(df)

    # Select and order features exactly as in training
    feature_names = meta.get("feature_names", ALL_FEATURES)
    X = df[feature_names].values

    # Scale
    X_scaled = scaler.transform(X)

    # Predict
    pred   = int(model.predict(X_scaled)[0])
    proba  = float(model.predict_proba(X_scaled)[0][1])   # P(Good Credit)
    label  = LABEL_MAP[pred]
    risk   = get_risk_level(proba)

    return {
        "prediction":  pred,
        "label":       label,
        "probability": round(proba, 4),
        "risk_level":  risk,
    }


def predict_batch(csv_path: str, output_csv: str = None) -> pd.DataFrame:
    """
    Predict creditworthiness for every row in a CSV file.

    Parameters
    ----------
    csv_path   : path to input CSV (must have the 10 original columns)
    output_csv : optional path to save results

    Returns
    -------
    DataFrame with original columns + prediction + probability + risk_level
    """
    model, scaler, meta = load_artifacts()

    df = pd.read_csv(csv_path)
    df_eng = engineer_features(df)

    feature_names = meta.get("feature_names", ALL_FEATURES)
    X_scaled = scaler.transform(df_eng[feature_names])

    df["prediction"]  = model.predict(X_scaled)
    df["label"]       = df["prediction"].map(LABEL_MAP)
    df["probability"] = model.predict_proba(X_scaled)[:, 1].round(4)
    df["risk_level"]  = df["probability"].apply(get_risk_level)

    if output_csv:
        df.to_csv(output_csv, index=False)
        log.info(f"Batch predictions saved → {output_csv}")

    return df


# ── Interactive demo ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("\n" + "═"*55)
    print("  Credit Scoring Model — Single Prediction Demo")
    print("═"*55)

    # Example applicant — feel free to change these values!
    sample = {
        "age": 35,
        "income": 65000,
        "employment_years": 8,
        "debt": 12000,
        "loan_amount": 15000,
        "credit_history_years": 10,
        "number_of_credit_cards": 3,
        "payment_history_score": 720,
        "missed_payments": 1,
        "credit_utilization": 0.3,
    }

    print("\nApplicant Profile:")
    for k, v in sample.items():
        print(f"  {k:<28} {v}")

    result = predict_single(sample)

    print(f"\n{'─'*55}")
    print(f"  Result      : {result['label']}")
    print(f"  Probability : {result['probability']:.2%}  (Good Credit)")
    print(f"  Risk Level  : {result['risk_level']}")
    print(f"{'═'*55}\n")
