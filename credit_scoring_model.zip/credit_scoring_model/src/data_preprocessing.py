"""
data_preprocessing.py
─────────────────────
Loads the raw CSV, cleans it, scales features, and splits into
train / test sets. Saves processed arrays to data/processed/.

Usage:
    python src/data_preprocessing.py
"""

import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import joblib

from utils import get_logger, data_path, ensure_dirs

log = get_logger("preprocessing")

# ── Column definitions ──────────────────────────────────────────────────────
NUMERIC_FEATURES = [
    "age", "income", "employment_years", "debt", "loan_amount",
    "credit_history_years", "number_of_credit_cards",
    "payment_history_score", "missed_payments", "credit_utilization",
]
TARGET_COL = "target"


def load_raw_data(filepath: str) -> pd.DataFrame:
    """Load CSV and do a quick sanity check."""
    log.info(f"Loading raw data from: {filepath}")
    df = pd.read_csv(filepath)
    log.info(f"Shape: {df.shape}  |  Columns: {list(df.columns)}")
    log.info(f"Missing values:\n{df.isnull().sum()[df.isnull().sum() > 0]}")
    return df


def handle_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """Fill numeric NaNs with the column median (robust to outliers)."""
    log.info("Handling missing values with median imputation …")
    for col in NUMERIC_FEATURES:
        if col in df.columns and df[col].isnull().any():
            median_val = df[col].median()
            df[col] = df[col].fillna(median_val)
            log.info(f"  {col}: filled NaNs with median={median_val:.2f}")
    return df


def remove_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """Drop exact duplicate rows."""
    before = len(df)
    df = df.drop_duplicates()
    log.info(f"Removed {before - len(df)} duplicate rows.")
    return df


def split_features_target(df: pd.DataFrame):
    """Return X (feature DataFrame) and y (Series)."""
    X = df[NUMERIC_FEATURES]
    y = df[TARGET_COL]
    return X, y


def scale_features(X_train: pd.DataFrame, X_test: pd.DataFrame):
    """
    Fit a StandardScaler on the training set and transform both splits.
    Returns scaled arrays and the fitted scaler object.
    """
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)   # fit + transform on train
    X_test_scaled  = scaler.transform(X_test)         # only transform on test
    log.info("Feature scaling complete (StandardScaler).")
    return X_train_scaled, X_test_scaled, scaler


def preprocess(raw_csv: str = None, test_size: float = 0.2, random_state: int = 42):
    """
    Full preprocessing pipeline:
      load → clean → split → scale → save
    Returns (X_train, X_test, y_train, y_test, scaler, feature_names).
    """
    ensure_dirs()

    if raw_csv is None:
        raw_csv = data_path("raw", "credit_data.csv")

    # 1. Load
    df = load_raw_data(raw_csv)

    # 2. Clean
    df = handle_missing_values(df)
    df = remove_duplicates(df)

    # 3. Split features / target
    X, y = split_features_target(df)
    log.info(f"Class distribution:\n{y.value_counts(normalize=True).round(3)}")

    # 4. Train-test split (stratified to preserve class balance)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    log.info(f"Train: {X_train.shape}  |  Test: {X_test.shape}")

    # 5. Scale
    X_train_sc, X_test_sc, scaler = scale_features(X_train, X_test)

    # 6. Save processed data
    out_dir = data_path("processed")
    np.save(os.path.join(out_dir, "X_train.npy"), X_train_sc)
    np.save(os.path.join(out_dir, "X_test.npy"),  X_test_sc)
    np.save(os.path.join(out_dir, "y_train.npy"), y_train.values)
    np.save(os.path.join(out_dir, "y_test.npy"),  y_test.values)
    joblib.dump(scaler, os.path.join(out_dir, "scaler.pkl"))
    log.info(f"Processed data saved to: {out_dir}")

    # Also save cleaned full dataframe for notebook exploration
    df.to_csv(data_path("processed", "credit_data_clean.csv"), index=False)

    return X_train_sc, X_test_sc, y_train.values, y_test.values, scaler, NUMERIC_FEATURES


if __name__ == "__main__":
    preprocess()
    log.info("Preprocessing complete ✓")
