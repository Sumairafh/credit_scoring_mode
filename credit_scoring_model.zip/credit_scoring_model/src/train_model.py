"""
train_model.py
──────────────
Trains three classifiers, picks the best by ROC-AUC,
saves it as models/credit_model.pkl, and writes report plots.

Usage:
    python src/train_model.py
"""

import os
import sys
import numpy as np
import joblib
import pandas as pd

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

# Allow running from project root or from src/
sys.path.insert(0, os.path.dirname(__file__))

from data_preprocessing import preprocess
from feature_engineering import engineer_features, ALL_FEATURES
from evaluate_model import evaluate, plot_reports
from utils import get_logger, data_path, model_path, ensure_dirs

log = get_logger("train")


# ── Model catalogue ──────────────────────────────────────────────────────────

def get_models() -> dict:
    """Return a dict of {model_name: unfitted_estimator}."""
    return {
        "Logistic Regression": LogisticRegression(
            max_iter=1000,
            random_state=42,
            class_weight="balanced",   # handle class imbalance
        ),
        "Decision Tree": DecisionTreeClassifier(
            max_depth=6,
            min_samples_leaf=10,
            random_state=42,
            class_weight="balanced",
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=200,
            max_depth=8,
            min_samples_leaf=5,
            random_state=42,
            n_jobs=-1,                 # use all CPU cores
            class_weight="balanced",
        ),
    }


# ── Feature engineering integration ─────────────────────────────────────────

def load_engineered_data():
    """
    Re-load the cleaned CSV, apply feature engineering, then scale.
    Returns (X_train, X_test, y_train, y_test, feature_names).
    """
    # First run preprocessing to produce cleaned CSV + scaler
    _, _, y_train_raw, y_test_raw, scaler, base_features = preprocess()

    # Load cleaned data and apply feature engineering
    clean_csv = data_path("processed", "credit_data_clean.csv")
    df = pd.read_csv(clean_csv)
    df = engineer_features(df)

    # Re-split using the same random state as preprocessing
    from sklearn.model_selection import train_test_split
    X = df[ALL_FEATURES]
    y = df["target"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Scale with the SAME scaler (fit on base features only → refit on all)
    from sklearn.preprocessing import StandardScaler
    sc = StandardScaler()
    X_train_sc = sc.fit_transform(X_train)
    X_test_sc  = sc.transform(X_test)

    # Overwrite scaler with the one that knows about engineered features
    import joblib, os
    joblib.dump(sc, os.path.join(data_path("processed"), "scaler.pkl"))

    return (X_train_sc, X_test_sc,
            y_train.values, y_test.values,
            ALL_FEATURES)


# ── Main training loop ───────────────────────────────────────────────────────

def train():
    ensure_dirs()
    log.info("Starting training pipeline …")

    X_train, X_test, y_train, y_test, feature_names = load_engineered_data()

    models = get_models()
    results = {}   # {name: metrics_dict}

    for name, clf in models.items():
        log.info(f"Training: {name}")
        clf.fit(X_train, y_train)
        metrics = evaluate(clf, X_test, y_test, model_name=name)
        results[name] = {"model": clf, "metrics": metrics}

    # ── Pick best model by ROC-AUC ──────────────────────────────────────────
    best_name = max(results, key=lambda n: results[n]["metrics"]["roc_auc"])
    best_model = results[best_name]["model"]
    best_metrics = results[best_name]["metrics"]

    log.info(f"\n🏆  Best model: {best_name}  (ROC-AUC = {best_metrics['roc_auc']:.4f})")

    # ── Save model ──────────────────────────────────────────────────────────
    out_path = model_path()
    joblib.dump(best_model, out_path)
    log.info(f"Model saved → {out_path}")

    # ── Save metadata ───────────────────────────────────────────────────────
    meta = {
        "best_model_name": best_name,
        "feature_names": feature_names,
        "metrics": best_metrics,
    }
    joblib.dump(meta, model_path("model_meta.pkl"))

    # ── Generate report plots ───────────────────────────────────────────────
    plot_reports(best_model, X_test, y_test, feature_names, model_name=best_name)

    # ── Summary table ───────────────────────────────────────────────────────
    print(f"\n{'═'*60}")
    print("  Model Comparison Summary")
    print(f"{'─'*60}")
    print(f"  {'Model':<25} {'Accuracy':>9} {'F1':>7} {'ROC-AUC':>9}")
    print(f"{'─'*60}")
    for name, r in results.items():
        m = r["metrics"]
        marker = " ◀ best" if name == best_name else ""
        print(f"  {name:<25} {m['accuracy']:>9.4f} {m['f1']:>7.4f} {m['roc_auc']:>9.4f}{marker}")
    print(f"{'═'*60}\n")

    return best_model, best_metrics


if __name__ == "__main__":
    train()
    log.info("Training pipeline complete ✓")
