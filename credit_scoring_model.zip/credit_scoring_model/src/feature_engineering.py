"""
feature_engineering.py
───────────────────────
Derives new informative features from the raw columns before training.
These ratios often improve model performance significantly.

Usage:
    from feature_engineering import engineer_features
    df_engineered = engineer_features(df)
"""

import pandas as pd
import numpy as np

from utils import get_logger, clip_ratio

log = get_logger("feature_engineering")


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add derived features to the DataFrame.
    Input DataFrame must contain the original raw columns.
    Returns a new DataFrame with extra columns appended.
    """
    df = df.copy()  # never mutate the caller's data

    # ── 1. Debt-to-Income Ratio ────────────────────────────────────────────
    # How much of income is already owed as debt?
    # High values → riskier borrower
    df["debt_to_income_ratio"] = clip_ratio(
        df["debt"].values, df["income"].values
    )
    log.info("Created: debt_to_income_ratio")

    # ── 2. Loan-to-Income Ratio ────────────────────────────────────────────
    # Requested loan relative to income — affordability signal
    df["loan_to_income_ratio"] = clip_ratio(
        df["loan_amount"].values, df["income"].values
    )
    log.info("Created: loan_to_income_ratio")

    # ── 3. Credit Cards per Income Unit ───────────────────────────────────
    # Many cards vs. low income can indicate over-extension
    df["credit_card_per_income"] = clip_ratio(
        df["number_of_credit_cards"].values,
        df["income"].values / 10_000        # scale income to $10k units
    )
    log.info("Created: credit_card_per_income")

    # ── 4. Payment Reliability Score ──────────────────────────────────────
    # Composite score blending payment history and missed payment penalty.
    # Normalise payment_history_score from [300, 850] → [0, 1]
    pay_norm = (df["payment_history_score"] - 300) / (850 - 300)
    missed_penalty = df["missed_payments"] / (df["missed_payments"].max() + 1e-9)
    df["payment_reliability_score"] = np.clip(pay_norm - missed_penalty, 0, 1)
    log.info("Created: payment_reliability_score")

    # ── 5. Total Obligations-to-Income ────────────────────────────────────
    # Combined debt + loan vs. income
    df["total_obligation_ratio"] = clip_ratio(
        (df["debt"] + df["loan_amount"]).values, df["income"].values
    )
    log.info("Created: total_obligation_ratio")

    # ── 6. Credit Experience Score ────────────────────────────────────────
    # Reward long credit history + stable employment
    df["credit_experience"] = (
        np.log1p(df["credit_history_years"]) +
        np.log1p(df["employment_years"])
    )
    log.info("Created: credit_experience")

    log.info(f"Feature engineering complete. New shape: {df.shape}")
    return df


# ── Engineered feature names (useful when building feature-importance plots) ─
ENGINEERED_FEATURES = [
    "debt_to_income_ratio",
    "loan_to_income_ratio",
    "credit_card_per_income",
    "payment_reliability_score",
    "total_obligation_ratio",
    "credit_experience",
]

ALL_FEATURES = [
    "age", "income", "employment_years", "debt", "loan_amount",
    "credit_history_years", "number_of_credit_cards",
    "payment_history_score", "missed_payments", "credit_utilization",
] + ENGINEERED_FEATURES


if __name__ == "__main__":
    # Quick smoke-test
    import sys, os
    sys.path.insert(0, os.path.dirname(__file__))
    from utils import data_path
    df = pd.read_csv(data_path("processed", "credit_data_clean.csv"))
    df_eng = engineer_features(df)
    print(df_eng[ENGINEERED_FEATURES].describe().round(3))
    log.info("feature_engineering.py smoke-test passed ✓")
