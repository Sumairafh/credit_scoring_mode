"""
evaluate_model.py
─────────────────
Evaluates a trained classifier and saves visual reports to reports/.

Usage:
    from evaluate_model import evaluate, plot_reports
"""

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")   # non-interactive backend — safe in scripts & Streamlit
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, roc_curve, classification_report,
)

from utils import get_logger, reports_path

log = get_logger("evaluate")


# ── Core metrics ─────────────────────────────────────────────────────────────

def compute_metrics(model, X_test: np.ndarray, y_test: np.ndarray) -> dict:
    """Return a dict with all key classification metrics."""
    y_pred  = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    metrics = {
        "accuracy":  round(accuracy_score(y_test, y_pred),  4),
        "precision": round(precision_score(y_test, y_pred, zero_division=0), 4),
        "recall":    round(recall_score(y_test, y_pred,    zero_division=0), 4),
        "f1":        round(f1_score(y_test, y_pred,        zero_division=0), 4),
        "roc_auc":   round(roc_auc_score(y_test, y_proba), 4),
    }
    return metrics


def evaluate(model, X_test: np.ndarray, y_test: np.ndarray,
             model_name: str = "Model") -> dict:
    """Print a full evaluation report and return metric dict."""
    metrics = compute_metrics(model, X_test, y_test)

    print(f"\n{'═'*50}")
    print(f"  {model_name} — Evaluation Results")
    print(f"{'═'*50}")
    for k, v in metrics.items():
        print(f"  {k.upper():12s}: {v:.4f}")
    print(f"{'─'*50}")

    y_pred = model.predict(X_test)
    print("\nClassification Report:\n")
    print(classification_report(y_test, y_pred,
                                target_names=["Bad Credit", "Good Credit"]))
    return metrics


# ── Plots ────────────────────────────────────────────────────────────────────

def plot_confusion_matrix(model, X_test, y_test, model_name="Model"):
    """Save a styled confusion-matrix heatmap."""
    y_pred = model.predict(X_test)
    cm = confusion_matrix(y_test, y_pred)

    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["Bad Credit", "Good Credit"],
                yticklabels=["Bad Credit", "Good Credit"],
                linewidths=0.5, ax=ax)
    ax.set_title(f"Confusion Matrix — {model_name}", fontsize=13, pad=12)
    ax.set_ylabel("Actual", fontsize=11)
    ax.set_xlabel("Predicted", fontsize=11)
    plt.tight_layout()

    out = reports_path("confusion_matrix.png")
    fig.savefig(out, dpi=150)
    plt.close(fig)
    log.info(f"Confusion matrix saved → {out}")


def plot_roc_curve(model, X_test, y_test, model_name="Model"):
    """Save a ROC curve plot."""
    y_proba = model.predict_proba(X_test)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, y_proba)
    auc = roc_auc_score(y_test, y_proba)

    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(fpr, tpr, color="#2563EB", lw=2,
            label=f"ROC (AUC = {auc:.3f})")
    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Random")
    ax.fill_between(fpr, tpr, alpha=0.08, color="#2563EB")
    ax.set_xlim([0, 1]); ax.set_ylim([0, 1.02])
    ax.set_xlabel("False Positive Rate", fontsize=11)
    ax.set_ylabel("True Positive Rate",  fontsize=11)
    ax.set_title(f"ROC Curve — {model_name}", fontsize=13, pad=12)
    ax.legend(loc="lower right")
    plt.tight_layout()

    out = reports_path("roc_curve.png")
    fig.savefig(out, dpi=150)
    plt.close(fig)
    log.info(f"ROC curve saved → {out}")


def plot_feature_importance(model, feature_names: list, model_name="Model"):
    """Save a horizontal bar chart of feature importances (tree models)."""
    if not hasattr(model, "feature_importances_"):
        log.warning(f"{model_name} has no feature_importances_ — skipping.")
        return

    importances = model.feature_importances_
    idx = np.argsort(importances)
    names = [feature_names[i] for i in idx]
    vals  = importances[idx]

    fig, ax = plt.subplots(figsize=(8, 6))
    colors = ["#2563EB" if v > np.median(vals) else "#93C5FD" for v in vals]
    ax.barh(names, vals, color=colors, edgecolor="white")
    ax.set_xlabel("Importance", fontsize=11)
    ax.set_title(f"Feature Importances — {model_name}", fontsize=13, pad=12)
    plt.tight_layout()

    out = reports_path("feature_importance.png")
    fig.savefig(out, dpi=150)
    plt.close(fig)
    log.info(f"Feature importance saved → {out}")


def plot_reports(model, X_test, y_test, feature_names, model_name="Best Model"):
    """Convenience wrapper: generate all three report plots at once."""
    plot_confusion_matrix(model, X_test, y_test, model_name)
    plot_roc_curve(model, X_test, y_test, model_name)
    plot_feature_importance(model, feature_names, model_name)
    log.info("All report plots generated ✓")
