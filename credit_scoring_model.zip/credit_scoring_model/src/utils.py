"""
utils.py — Shared helper functions used across the project.
"""

import os
import logging
import numpy as np


# ─────────────────────────────────────────────
# Logging setup
# ─────────────────────────────────────────────

def get_logger(name: str) -> logging.Logger:
    """Return a logger that prints timestamped messages to the console."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s",
                                datefmt="%H:%M:%S")
        handler.setFormatter(fmt)
        logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    return logger


# ─────────────────────────────────────────────
# Path helpers
# ─────────────────────────────────────────────

def project_root() -> str:
    """Return the absolute path to the project root folder."""
    # This file lives in src/, so go one level up.
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def data_path(*parts) -> str:
    return os.path.join(project_root(), "data", *parts)


def model_path(filename: str = "credit_model.pkl") -> str:
    return os.path.join(project_root(), "models", filename)


def reports_path(filename: str = "") -> str:
    return os.path.join(project_root(), "reports", filename)


# ─────────────────────────────────────────────
# Misc helpers
# ─────────────────────────────────────────────

def ensure_dirs():
    """Create any missing output directories."""
    for folder in ["data/processed", "models", "reports"]:
        os.makedirs(os.path.join(project_root(), folder), exist_ok=True)


def clip_ratio(numerator: np.ndarray, denominator: np.ndarray,
               max_val: float = 10.0) -> np.ndarray:
    """Safe division that clamps the result and avoids divide-by-zero."""
    denom = np.where(denominator == 0, 1e-9, denominator)
    return np.clip(numerator / denom, 0, max_val)
