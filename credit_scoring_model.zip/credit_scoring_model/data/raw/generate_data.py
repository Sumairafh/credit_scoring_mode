"""
Script to generate synthetic credit scoring dataset.
Run this once to create credit_data.csv in the same folder.
"""

import numpy as np
import pandas as pd

np.random.seed(42)
n = 2000

age = np.random.randint(20, 70, n)
income = np.random.randint(20000, 150000, n)
employment_years = np.random.randint(0, 40, n)
debt = np.random.randint(0, 80000, n)
loan_amount = np.random.randint(1000, 60000, n)
credit_history_years = np.random.randint(0, 30, n)
number_of_credit_cards = np.random.randint(0, 10, n)
payment_history_score = np.random.randint(300, 850, n)
missed_payments = np.random.randint(0, 15, n)
credit_utilization = np.round(np.random.uniform(0, 1, n), 2)

# Build target based on heuristics
score = (
    (payment_history_score > 650).astype(int) * 2
    + (debt / (income + 1) < 0.4).astype(int) * 2
    + (missed_payments < 3).astype(int) * 2
    + (employment_years > 3).astype(int)
    + (credit_utilization < 0.5).astype(int)
    + (credit_history_years > 5).astype(int)
)
target = (score >= 5).astype(int)

df = pd.DataFrame({
    "age": age,
    "income": income,
    "employment_years": employment_years,
    "debt": debt,
    "loan_amount": loan_amount,
    "credit_history_years": credit_history_years,
    "number_of_credit_cards": number_of_credit_cards,
    "payment_history_score": payment_history_score,
    "missed_payments": missed_payments,
    "credit_utilization": credit_utilization,
    "target": target,
})

# Introduce ~3% missing values for realism
for col in ["income", "employment_years", "payment_history_score"]:
    idx = np.random.choice(df.index, size=int(0.03 * n), replace=False)
    df.loc[idx, col] = np.nan

df.to_csv("credit_data.csv", index=False)
print(f"Dataset saved: {len(df)} rows, {df['target'].mean():.1%} good credit")
